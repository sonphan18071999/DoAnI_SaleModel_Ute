﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace WindowsFormsApp1.Usercontrol
{
    public partial class UCNhapKho : UserControl
    {
        public UCNhapKho()
        {
            InitializeComponent();
        }
        MY_DB connect = new MY_DB();
      
        SanPham sp = new SanPham();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioBtClick()
        {
            msp.Text = "";
            masp1.Text = "";
            tensp1.Text = "";
            dvt1.Text = "";
            dgia1.Text = "";
            sl1.Text = "";
            tensp.Text = "";
            dvt.Text = "";
            dg.Text = "";
            sl.Text = "";
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            connect.openConnection();
            DataTable a = new DataTable();
            dataGridView1.DataSource = a;
            SqlCommand sql = new SqlCommand("select * from SanPham", connect.getConnection);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql);
            dataAdapter.Fill(a);
            dataGridView1.DataSource = a;
            connect.closeConnection();
        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            radioBtClick();
        }



        private void UCNhapKho_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
            radioBtClick();
        }

        private void taihinh_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if ((opf.ShowDialog() == DialogResult.OK))
            {
                pictureBox2.Image = Image.FromFile(opf.FileName);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemoryStream pic = new MemoryStream();
            string ma = masp1.Text;
            string ten = tensp1.Text;
            string dv = dvt1.Text;
            string dg = dgia1.Text;
            string sol = sl1.Text;
            pictureBox2.Image.Save(pic, pictureBox2.Image.RawFormat);
            if (sp.KTtonTai(ma).Rows.Count < 1)
            {
                if (sp.themSP(ma, ten, dv, dg, sol, pic) == true)
                {
                    DialogResult dlr = MessageBox.Show("Sản Phẩm mới được thêm vào!", "Thêm SP", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr == DialogResult.OK)
                    {
                        radioBtClick();
                    }
                }
                else
                {
                    MessageBox.Show("Lỗi", "Thêm SP", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            msp.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            tensp.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            dvt.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            dg.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            sl.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            byte[] pic;
            pic = (byte[])dataGridView1.CurrentRow.Cells[5].Value;
            MemoryStream picture = new MemoryStream(pic);
            pictureBox1.Image = Image.FromStream(picture);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ma = msp.Text;
            DialogResult dlr = MessageBox.Show("Bạn có muốn xóa SP này ko!", "Xóa SP", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes)
            {
                if (sp.xoaSP(ma) == true)
                {
                    DialogResult dlr1 = MessageBox.Show("Đã xóa!", "Xóa SP", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr1 == DialogResult.OK)
                    {
                        radioBtClick();
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MemoryStream pic1 = new MemoryStream();
            string ma = msp.Text;
            string ten = tensp.Text;
            string dv = dvt.Text;
            string dongia = dg.Text;
            string sol = sl.Text;
            pictureBox1.Image.Save(pic1, pictureBox1.Image.RawFormat);
            if (sp.chinhsuaSP(ma, ten, dv, dongia, sol, pic1) == true)
            {
                DialogResult dlr = MessageBox.Show("Sản Phẩm được thay đổi thông tin!", "Thêm SP", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (dlr == DialogResult.OK)
                {
                    radioBtClick();
                }
            }

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if ((opf.ShowDialog() == DialogResult.OK))
            {
                pictureBox1.Image = Image.FromFile(opf.FileName);
            }
        }

        

        private void button7_Click(object sender, EventArgs e)
        {
            radioBtClick();
        }

        private void findTxt_TextChanged(object sender, EventArgs e)
        {
            connect.openConnection();
            DataTable a = new DataTable();
            dataGridView1.DataSource = a;
            SqlCommand command = new SqlCommand("select * from SanPham where TenSP like N'%" + findTxt.Text + "%'", connect.getConnection);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            dataAdapter.Fill(a);
            dataGridView1.DataSource = a;
            connect.closeConnection();
        }
    }
}
