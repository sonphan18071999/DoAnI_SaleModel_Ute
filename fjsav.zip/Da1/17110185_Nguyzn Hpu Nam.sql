delete from PNHAP where SOPN='N002'

drop procedure spud_TinhSLConNhap
create proc spud_TinhSLConNhap @sodathang char(4), @mavattu char(4)
as
begin
declare @soluongconnhap int
select @soluongconnhap = sum(SLDAT)- sum(SLNHAP)
from CTPNHAP A inner join CTDONDH B on A.MAVTU = B.MAVTU
where (@sodathang = SODH) and (@mavattu = A.MAVTU )
print @soluongconnhap
end

exec spud_TinhSLConNhap 'D001', 'DD01' 

--------------------------------------------------------------------

drop function Fn_Giam_DGX
use quanlibanhang
create function Fn_Giam_DGX(@PhanTramGiam real, @MucGiam int) 
Returns table
AS
   return (
   select b.MAVTU,b.TENVTU,b.DVITINH,a.DGXUAT-a.DGXUAT*@PhanTramGiam/100 DONGIA,a.SOPX,a.SLXUAT,a.DGXUAT
   from CTPXUAT a inner join VATTU b
   on a.MAVTU=b.MAVTU and a.SLXUAT>@MucGiam
   )
go
select * from dbo.Fn_Giam_DGX(20,2)

--------------------------------------------------------------------

create function Fn_LietKeDDH_NCC(@Manhacc char(4))
returns table
as
   return (
   select b.SODH
   from NHACC a inner join DONDH b
   on b.MANHACC=a.MANHACC and a.MANHACC=@Manhacc
   )
go
select * from dbo.Fn_LietKeDDH_NCC('C02')

--------------------------------------------------------------------

create procedure spud_TinhSLNhap @mavattu char(4),@sodh char(4)
as
 begin
   declare @dem int 
   select @dem=sum(b.SLNHAP)
   from CTPNHAP a inner join CTDONDH b on a.MAVTU=b.MAVTU
   where b.SODH=@sodh and b.MAVTU=@mavattu
   print @dem
end

--------------------------------------------------------------------

create proc spud_TinhSLNhap @sodathang char(4), @mavattu char(4)
as
declare @soluongdat int
select @soluongdat = sum(SLDAT)
from CTPNHAP Aright join CTDONDH B on A.MAVTU = B.MAVTU
where (@sodathang = SODH) and (@mavattu = A.MAVTU )
print @soluongdat

--------------------------------------------------------------------
drop proc spud_DONDH_TinhSLDat
use quanlibanhang
create proc spud_DONDH_TinhSLDat @sodathang char(4), @mavattu char(4),@soluongdat int out
as
begin
declare @a int
select @a = SLDAT
from  CTDONDH 
where (@sodathang = SODH) and (@mavattu = MAVTU )
set @soluongdat=@a
end
declare @sld int
exec spud_DONDH_TinhSLDat 'D001','DD01',@sld out
select @sld

--------------------------------------------------------------------

drop proc spud_TONKHO_BcaoTonkho
create proc spud_TONKHO_BcaoTonkho @ngay char(6)
as
begin
 select a.NAMTHANG,a.SLDAU,a.TONGSLNHAP,a.TONGSLXUAT,a.SLCUOI,b.TENVTU,b.DVITINH,b.PHANTRAM
 from TONKHO a inner join VATTU b on a.MAVTU=b.MAVTU
 where a.NAMTHANG=@ngay
end

exec spud_TONKHO_BcaoTonkho '200601'

--------------------------------------------------------------------

drop proc spud_HienThi_DDH
create proc spud_HienThi_DDH  @ngay char(6)
as
begin
 select a.SODH, NGAYDH, MANHACC,GHICHU = case when (count(b.SOPN)<>0) then N'C� ' + cast((count(b.SOPN)) as varchar(3))+ N' phi?u
nh?p h�ng' else N'Ch?a c� nh?p h�ng' end
 from DONDH a left join PNHAP b on a.SODH=b.SODH
 where CONVERT(CHAR(4), a.NGAYDH, 120) +  RIGHT('00' + RTRIM( CAST( DATEPART( MONTH, a.NGAYDH ) AS varchar(2)) ) , 2)=@ngay
 group by a.SODH, a.NGAYDH, a.MANHACC
end
exec spud_HienThi_DDH '200602'


--------------------------------------------------------------------

drop procedure spud_TinhSLDat
create proc spud_TinhSLDat @sodathang char(4), @mavattu char(4)
as
begin
declare @soluongdathang int
select @soluongdathang = sum(SLDAT)
from CTDONDH
where (@sodathang = SODH) and (@mavattu =MAVTU )
print @soluongdathang
end
exec spud_TinhSLDat 'D001','DD02'

--------------------------------------------------------------------

drop procedure spud_TinhTienNhap_200901
create proc spud_TinhTienNhap_200602
as
begin
 select sum(DGNHAP)
 from CTPNHAP a inner join PNHAP b on a.SOPN=b.SOPN
 where  CONVERT(CHAR(4), b.NGAYNHAP, 120) +  RIGHT('00' + RTRIM( CAST( DATEPART( MONTH, b.NGAYNHAP ) AS varchar(2)) ) , 2)='200602'

end
exec spud_TinhTienNhap_200602

--------------------------------------------------------------------

drop function Fn_LietKePN
create function Fn_LietKePN(@Sodh char(4))
returns table
as
   return (
   select distinct a.SOPN
   from PNHAP a
   where a.SODH=@Sodh 
   )
go
select * from dbo.Fn_LietKePN('D003') 

--------------------------------------------------------------------

create function Fn_CacSoNT(@n int)
returns varchar(1000) 
as
begin 
declare @kq varchar(1000), @i int, @a int
set @i = 1
set @kq = '' 
while (@i <= @n)
begin
 set @a = dbo.Fn_SoNT(@i)
 if (@a = 1)
 begin
  set @kq = @kq + cast(@i as varchar(4)) + ', ' set @i = @i + 1
end
else
  set @i = @i + 1
 end
return (@kq)
endprint dbo.Fn_CacSoNT(10)

-------------------------------------------

create function Fn_SoNT(@n int)
returns int as
begin
  declare @i int,@dem int,@kq int
  set @i=2
  while(@i<@n)
  begin
    if(@n%@i=0 and @n!=2)
	begin
	    set @kq=0
		break
	end
	else
	begin
	   set @i=@i+1
	end
  end
  if (@i = @n or @n = 2)
    begin
      set @kq = 1
    end
  return @kq
end

print dbo.Fn_SoNT(4)

-------------------------------------------
drop function  Fn_TongDaySo
create function Fn_TongDaySo(@n int) 
returns int as
begin
   declare @tong int,@i int
   set @i=0
   set @tong=0
   while(@i<=@n)
   begin
       set @tong=@tong+@i
	   set @i=@i+1
   end
   return @tong
end
-------------------------------------------

print dbo.Fn_TongDaySo(3)


create function Fn_TongHaiSo(@So1 int, @So2 int)
returns int
begin
  return @So1+@So2 
end
print dbo.Fn_TongHaiSo(10,11)
