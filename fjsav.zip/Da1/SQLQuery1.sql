
truncate table nhanvien
update lamviec set trangthai=0
select * from HoaDon where Convert(date,GETDATE())=CONVERT(date,Ngay) and CONVERT(time,Ngay)>'07:00:00' and CONVERT(time,Ngay)<'12:00:00'