﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class lienlac : Form
    {
        DataProvider dtp = new DataProvider();
        public lienlac()
        {
            InitializeComponent();
        }

        private void lienlac_Load(object sender, EventArgs e)
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("select * from chinhanh", dtp.connection);
            DataTable a = new DataTable();
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            dtp.disconnect();
            dta.Fill(a);
            cbdate.DataSource = a;
            cbdate.DisplayMember = "Diachi";
            cbdate.ValueMember = "STT";
            Timer ti = new Timer();
            ti.Interval = 5000;
            ti.Tick += A_Tick;
            ti.Start();


    
        }
        private void A_Tick(object sender, EventArgs e)
        {
            DataTable a = new DataTable();
            int cs = Convert.ToInt16(cbdate.SelectedValue.ToString()) + 1;
            string from = "cn" + cs.ToString();
            ser.connect();
            SqlCommand sql1 = new SqlCommand("select * from lienlac where ([from]=@fr and [to]=@to) or ([from]=@to and [to]=@fr) and trangthai=0 ORDER BY day DESC", ser.connection);
            sql1.Parameters.Add("@fr", SqlDbType.NChar).Value = from;
            sql1.Parameters.Add("@to", SqlDbType.NChar).Value = "server";
            DataTable b = new DataTable();
            SqlDataAdapter dta1 = new SqlDataAdapter(sql1);
            dta1.Fill(b);
            if (b.Rows.Count < 10)
            {
                SqlCommand sql = new SqlCommand("select top 10 * from lienlac where ([from]=@fr and [to]=@to) or ([from]=@to and [to]=@fr) ORDER BY day DESC", ser.connection);
                sql.Parameters.Add("@fr", SqlDbType.NChar).Value = from;
                sql.Parameters.Add("@to", SqlDbType.NChar).Value = "server";
                a = new DataTable();
                SqlDataAdapter dta = new SqlDataAdapter(sql);
                dta.Fill(a);
            }
            else
            {
                a = new DataTable();
                a = b;
            }
            ser.disconnect();
            for (int i = a.Rows.Count - 1; i >= 0; i--)
            {
                if (a.Rows[i][0].ToString().Trim() == from && a.Rows[i][1].ToString().Trim() == "server" && Convert.ToInt16(a.Rows[i][4])==0)
                {
                    RichTextBox rtb = new RichTextBox();

                   
                        rtb.Cursor = Cursors.Arrow;
                        rtb.TabStop = false;
                        rtb.BackColor = Color.Azure;
                        rtb.ReadOnly = true;
                    
                  

                    rtb.SelectionColor = Color.Red;
                    rtb.MaximumSize = new Size(200, 50000);
                    string hour = a.Rows[i][3].ToString().Trim();
                    string nd = a.Rows[i][2].ToString().Trim();
                    string a1;
                    string a2;
                    if (hour.Length > nd.Length)
                    {
                        a1 = hour;
                        a2 = nd;
                    }
                    else
                    {
                        a1 = nd;
                        a2 = hour;
                    }
                    rtb.AppendText(a.Rows[i][3].ToString().Trim() + Environment.NewLine);
                    rtb.SelectionColor = Color.Black;
                    rtb.AppendText(a.Rows[i][2].ToString().Trim());
                    using (Graphics g = CreateGraphics())
                    {
                        rtb.Width = (int)g.MeasureString(a1,
                            rtb.Font).Width + 100;
                        int k = (int)g.MeasureString(a1, rtb.Font).Width / rtb.MaximumSize.Width;
                        int h = k + 2;
                        rtb.Height = h * (int)g.MeasureString(a1,
                           rtb.Font).Height;

                    }
                    rtb.Multiline = true;
                    rtb.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
                    rtb.Location = new Point(10, ly);
                    rtb.BorderStyle = System.Windows.Forms.BorderStyle.None;


                    panel1.Controls.Add(rtb);

                    ly = ly + rtb.Size.Height + 5;

                    seen(Convert.ToDateTime(a.Rows[i][3]), from, "server");


                }
            }
            ser.disconnect();


        }
        private void seen(DateTime a, string from, string to)
        {
            ser.connect();
            SqlCommand sql = new SqlCommand("update lienlac set trangthai=1 where [from]=@fr and [to]=@to and day=@day", ser.connection);
            sql.Parameters.Add("@fr", SqlDbType.NChar).Value = from;
            sql.Parameters.Add("@to", SqlDbType.NChar).Value = to;
            string w = a.ToString("yyyy-MM-dd HH:mm:ss.fff");
            sql.Parameters.Add("@day", SqlDbType.DateTime).Value = w;
            sql.ExecuteNonQuery();
            ser.connect();
        }
        DataProvider ser = new DataProvider();

        int lx = 0;
        int ly = 0;
        private void cbdate_SelectedValueChanged(object sender, EventArgs e)
        {
           
        }
        private void load(string from,DataTable a)
        {
            ser.connect();
            SqlCommand sql1 = new SqlCommand("select * from lienlac where ([from]=@fr and [to]=@to) or ([from]=@to and [to]=@fr) and trangthai=0 ORDER BY day DESC", ser.connection);
            sql1.Parameters.Add("@fr", SqlDbType.NChar).Value = from;
            sql1.Parameters.Add("@to", SqlDbType.NChar).Value = "server";
            DataTable b = new DataTable();
            SqlDataAdapter dta1 = new SqlDataAdapter(sql1);
            dta1.Fill(b);
            if (b.Rows.Count < 10)
            {
                SqlCommand sql = new SqlCommand("select top 10 * from lienlac where ([from]=@fr and [to]=@to) or ([from]=@to and [to]=@fr) ORDER BY day DESC", ser.connection);
                sql.Parameters.Add("@fr", SqlDbType.NChar).Value = from;
                sql.Parameters.Add("@to", SqlDbType.NChar).Value = "server";
                a = new DataTable();
                SqlDataAdapter dta = new SqlDataAdapter(sql);
                dta.Fill(a);
            }
            else
            {
                a = new DataTable();
                a = b;
            }
            ser.disconnect();
            for (int i = a.Rows.Count - 1; i >= 0; i--)
            {
                if (a.Rows[i][0].ToString().Trim() == from && a.Rows[i][1].ToString().Trim() == "server")
                {
                    RichTextBox rtb = new RichTextBox();

                    if (Convert.ToInt16(a.Rows[i][4]) == 0)
                    {
                        rtb.Cursor = Cursors.Arrow;
                        rtb.TabStop = false;
                        rtb.BackColor = Color.Azure;
                        rtb.ReadOnly = true;
                    }
                    if (Convert.ToInt16(a.Rows[i][4]) == 1)
                    {
                        rtb.Cursor = Cursors.Arrow;
                        rtb.TabStop = false;
                        rtb.BackColor = Color.SeaGreen;
                        rtb.ReadOnly = true;
                    }

                    rtb.SelectionColor = Color.Red;
                    rtb.MaximumSize = new Size(200, 50000);
                    string hour = a.Rows[i][3].ToString().Trim();
                    string nd = a.Rows[i][2].ToString().Trim();
                    string a1;
                    string a2;
                    if (hour.Length > nd.Length)
                    {
                        a1 = hour;
                        a2 = nd;
                    }
                    else
                    {
                        a1 = nd;
                        a2 = hour;
                    }
                    rtb.AppendText(a.Rows[i][3].ToString().Trim() + Environment.NewLine);
                    rtb.SelectionColor = Color.Black;
                    rtb.AppendText(a.Rows[i][2].ToString().Trim());
                    using (Graphics g = CreateGraphics())
                    {
                        rtb.Width = (int)g.MeasureString(a1,
                            rtb.Font).Width + 100;
                        int k = (int)g.MeasureString(a1, rtb.Font).Width / rtb.MaximumSize.Width;
                        int h = k + 2;
                        rtb.Height = h * (int)g.MeasureString(a1,
                           rtb.Font).Height;

                    }
                    rtb.Multiline = true;
                    rtb.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
                    rtb.Location = new Point(2, ly);
                    rtb.BorderStyle = System.Windows.Forms.BorderStyle.None;


                    panel1.Controls.Add(rtb);

                    ly = ly + rtb.Size.Height + 5;

                    seen(Convert.ToDateTime(a.Rows[i][3]), from, "server");


                }
            }
            ser.disconnect();
        }
        private void cbdate_ValueMemberChanged(object sender, EventArgs e)
        {
            dtp.connect();
            DataTable a = new DataTable();
            int cs = Convert.ToInt16(cbdate.SelectedValue.ToString()) + 1;
            string from = "cn" + cs.ToString();
            load(from,a);
        }
    }
}
