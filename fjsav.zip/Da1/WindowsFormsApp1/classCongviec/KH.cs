﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;

namespace WindowsFormsApp1.classCongviec
{
    class KH
    {
        DataProvider dta = new DataProvider();
        public bool xoaKhachhang(string sdt)
        {
            dta.connect();
            SqlCommand command = new SqlCommand("delete from khachhang where sdt='" + sdt + "'", dta.connection);
            if (command.ExecuteNonQuery() == 1)
            {
                dta.disconnect();
                return true;
            }
            return false;

        }
    }
}
