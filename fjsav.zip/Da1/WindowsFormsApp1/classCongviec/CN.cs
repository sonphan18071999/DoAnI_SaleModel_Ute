﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data.OleDb;

namespace WindowsFormsApp1.classCongviec
{
    class CN
    {
        DataProvider dtp = new DataProvider();
        public bool themchinhanh(int stt,string dc,float tienmb)
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("insert into chinhanh(STT,Diachi,ngaykhanhthanh,tienmatbang,trangthai) values(@stt,@dc,@nkt,@tmb,@tt)", dtp.connection);
            sql.Parameters.Add("@stt", SqlDbType.Int).Value = stt;
            sql.Parameters.Add("@dc", SqlDbType.NVarChar).Value = dc;
            sql.Parameters.Add("@nkt", SqlDbType.Date).Value = DateTime.Now;
            sql.Parameters.Add("@tmb", SqlDbType.Float).Value = tienmb;
            sql.Parameters.Add("@tt", SqlDbType.Int).Value =1;
            if (sql.ExecuteNonQuery() == 1)
            {
                dtp.disconnect();
                return true;
            }
            return false;
        }
        public bool xoachinhanh(int stt)
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("update chinhanh set trangthai=0 where STT=@stt");
            sql.Parameters.Add("@name", SqlDbType.Int).Value = stt;
            if (sql.ExecuteNonQuery() == 1)
            {
                dtp.disconnect();
                return true;
            }
            return false;
        }
    }
}
