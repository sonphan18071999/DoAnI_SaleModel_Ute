﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;

namespace WindowsFormsApp1.classCongviec
{
    class NV
    {
        DataProvider dt = new DataProvider();
        public DataTable kiemtraNV(string user)
        {
            dt.connect();
            SqlCommand sql = new SqlCommand("select * from quanli where [User]=@user", dt.connection);
            sql.Parameters.Add("@user", SqlDbType.NVarChar).Value = user;
            
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            DataTable a = new DataTable();
            dta.Fill(a);
            return a;
        }
        public bool themNV(string user, string ten, string pass, string dc, DateTime ns, string sdt, float luong, int chinhanh)
        {
            dt.connect();
            SqlCommand sql = new SqlCommand("insert into nhanvien([User],Password,diachi,ngaysinh,sdt,giolam,luong,chinhanh,ten) values (@us,@pas,@dc,@ns,@sdt,@gl,@luong,@cn,@ten)", dt.connection);
            sql.Parameters.Add("@us", SqlDbType.NVarChar).Value = user;
            sql.Parameters.Add("@pas", SqlDbType.NVarChar).Value = pass;
            sql.Parameters.Add("@ns", SqlDbType.Date).Value = ns;
   
            sql.Parameters.Add("@dc", SqlDbType.NVarChar).Value = dc;
            sql.Parameters.Add("@sdt", SqlDbType.NVarChar).Value = sdt;
            sql.Parameters.Add("@gl", SqlDbType.Int).Value = 0;
            sql.Parameters.Add("@luong", SqlDbType.Float).Value = luong;
            sql.Parameters.Add("@cn", SqlDbType.Int).Value = chinhanh;
            sql.Parameters.Add("@ten", SqlDbType.NVarChar).Value = ten;
            if (sql.ExecuteNonQuery() == 1)
            {
                dt.disconnect();
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool SuaQL(string user, string ten, string pass, string dc, DateTime ns, string sdt, float luong, int chinhanh)
        {
            dt.connect();
            SqlCommand sql = new SqlCommand("update quanli set Password=@pas,diachi=@dc,ngaysinh=@ns,sdt=@sdt,luong=@luong,chinhanh=@cn,ten=@ten where [User]=@us", dt.connection);
            sql.Parameters.Add("@us", SqlDbType.NVarChar).Value = user;
            sql.Parameters.Add("@pas", SqlDbType.NVarChar).Value = pass;
            sql.Parameters.Add("@ns", SqlDbType.Date).Value = ns;

            sql.Parameters.Add("@dc", SqlDbType.NVarChar).Value = dc;
            sql.Parameters.Add("@sdt", SqlDbType.NVarChar).Value = sdt;
      
            sql.Parameters.Add("@luong", SqlDbType.Float).Value = luong;
            sql.Parameters.Add("@cn", SqlDbType.Int).Value = chinhanh;
            sql.Parameters.Add("@ten", SqlDbType.NVarChar).Value = ten;
            if (sql.ExecuteNonQuery() == 1)
            {
                dt.disconnect();
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool xoaQL(string user)
        {
            dt.connect();
            SqlCommand laythongtin = new SqlCommand("delete from quanli where [User]='" + user.Trim() + "'", dt.connection);
            if (laythongtin.ExecuteNonQuery() == 1)
            {
                dt.disconnect();
                return true;
            }
            else
            {
                dt.disconnect();
                return false;
            }
        }
        private static Random random = new Random();
        static Random _random = new Random();
        public string TaoRandom(int size)
        {
            string result = "NV";
            for (int i = 0; i < size; i++)
            {
                result = String.Concat(result, _random.Next(0, 10).ToString());
            }
            return result;
        }
        public bool giangcap(string user,int chinhanh)
        {
            dt.connect();
            SqlCommand laythongtin = new SqlCommand("select * from quanli where chinhanh="+chinhanh+" and [User]='"+user+"'", dt.connection);
            SqlDataAdapter ad = new SqlDataAdapter(laythongtin);
            DataTable dtb = new DataTable();
            ad.Fill(dtb);
            string usr="";
            bool kt = true;
            while (kt == true)
            {
                usr = TaoRandom(3);
                SqlCommand sql = new SqlCommand("select * from nhanvien where [User]='"+usr+"'",dt.connection);
                DataTable a = new DataTable();
                SqlDataAdapter adt = new SqlDataAdapter(sql);
                adt.Fill(a);
                if(a.Rows.Count==0)
                {
                    kt = false;
                }
                else
                {
                    kt = true;
                }
            }

            string pass = dtb.Rows[0][1].ToString();
            string dc = dtb.Rows[0][2].ToString();
            DateTime ns = Convert.ToDateTime(dtb.Rows[0][3].ToString());
            string sdt = dtb.Rows[0][4].ToString();
            float luong = float.Parse(dtb.Rows[0][5].ToString());
            int cn = Convert.ToInt32(dtb.Rows[0][6].ToString());
            string ten = dtb.Rows[0][7].ToString();
            if (xoaQL(user) == true)
            {
                if (themNV(usr, ten, pass, dc, ns, sdt, luong, cn) == true)
                {

                    return true;

                }
            }
            return false;
        }
        public bool thangcap(string user)
        {
            dt.connect();
            SqlCommand sql = new SqlCommand("update nhanvien set Type=@type where [User]=@user", dt.connection);
            sql.Parameters.Add("@user", SqlDbType.NVarChar).Value = user.Trim();
            sql.Parameters.Add("@type", SqlDbType.NChar).Value = "QL";
            if (sql.ExecuteNonQuery() == 1)
            {
                dt.disconnect();
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool themQL(string user,string ten,string pass,string dc,DateTime ns,string sdt,float luong,int chinhanh)
        {
            dt.connect();
            SqlCommand sql = new SqlCommand("insert into quanli([User],Password,diachi,ngaysinh,sdt,luong,chinhanh,ten) values (@us,@pas,@dc,@ns,@sdt,@luong,@cn,@ten)",dt.connection);
            sql.Parameters.Add("@us", SqlDbType.NVarChar).Value = user;
            sql.Parameters.Add("@pas", SqlDbType.NVarChar).Value = pass;
            sql.Parameters.Add("@ns", SqlDbType.Date).Value = ns.Date;
            sql.Parameters.Add("@dc", SqlDbType.NVarChar).Value = dc;
            sql.Parameters.Add("@sdt", SqlDbType.NVarChar).Value = sdt;
            sql.Parameters.Add("@luong", SqlDbType.Float).Value = luong;
            sql.Parameters.Add("@cn", SqlDbType.Int).Value = chinhanh;
            sql.Parameters.Add("@ten", SqlDbType.NVarChar).Value = ten;
            if (sql.ExecuteNonQuery()==1)
            {
                dt.disconnect();
                return true;
            }
            else
            {
                return false;
            }


        }
    }
}
