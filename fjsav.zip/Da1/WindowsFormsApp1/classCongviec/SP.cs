﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace WindowsFormsApp1.classCongviec
{
    class SP
    {
        DataProvider data = new DataProvider();
        public bool themsp(string msp, string tsp,int cty, float giaban, string dv,DateTime nsx,DateTime hsd,float per,int sl)
        {
            data.connect();
            SqlCommand command = new SqlCommand("insert into sanpham (maSp,tenSP,Cty,GiabanSP,Donvi,nsx,hsd,phantram,soluong) values (@msp,@tensp,@cty,@giabanSP,@dv,@nsx,@hsd,@pt,@sl)", data.connection);
            command.Parameters.Add("@msp", SqlDbType.NVarChar).Value = msp;
            command.Parameters.Add("@tensp", SqlDbType.NVarChar).Value = tsp;
            command.Parameters.Add("@cty", SqlDbType.Int).Value = cty;
            command.Parameters.Add("@giabanSP", SqlDbType.Float).Value = giaban;
            command.Parameters.Add("@dv", SqlDbType.NVarChar).Value = dv;
            command.Parameters.Add("@nsx", SqlDbType.Date).Value = nsx;
            command.Parameters.Add("@hsd", SqlDbType.Date).Value = hsd;
            command.Parameters.Add("@pt", SqlDbType.Float).Value = per;
            command.Parameters.Add("@sl", SqlDbType.Int).Value =sl;
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool xoasp(string masp,DateTime nsx)
        {
            data.connect();
            SqlCommand command = new SqlCommand("delete from sanpham where maSp=N'" + masp + "' and nsx='"+nsx+"'", data.connection);
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool suasp(string msp, string tsp, int cty, float giaban, string dv, DateTime nsx, DateTime hsd, float per, int sl)
        {
            data.connect();
            SqlCommand command = new SqlCommand("update sanpham set tenSP=@tsp,Cty=@cty,GiabanSP=@giabanSP,Donvi=@dv,nsx=@nsx,hsd=@hsd,phantram=@pt,soluong=@sl where maSp='"+msp+"'", data.connection);
            command.Parameters.Add("@tsp", SqlDbType.NVarChar).Value = tsp;
            command.Parameters.Add("@cty", SqlDbType.Int).Value = cty;
            command.Parameters.Add("@giabanSP", SqlDbType.Float).Value = giaban;
            command.Parameters.Add("@dv", SqlDbType.NVarChar).Value = dv;
            command.Parameters.Add("@nsx", SqlDbType.Date).Value = nsx;
            command.Parameters.Add("@hsd", SqlDbType.Date).Value = hsd;
            command.Parameters.Add("@pt", SqlDbType.Float).Value = per;
            command.Parameters.Add("@sl", SqlDbType.Int).Value = sl;
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool themslkhitontai(string msp, DateTime nsx, int sl)
        {
            data.connect();
            SqlCommand sql = new SqlCommand("update sanpham set soluong=soluong+@sl where maSp=@msp and nsx=@nsx", data.connection);
            sql.Parameters.Add("@msp", SqlDbType.NVarChar).Value = msp;
            sql.Parameters.Add("@sl", SqlDbType.Int).Value = sl;
            sql.Parameters.Add("@nsx", SqlDbType.DateTime).Value = nsx;
            if (sql.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool chapnhansp(string msp)
        {
            data.connect();
            SqlCommand command = new SqlCommand("update yeucau set trangthai=1 where maSp='" + msp + "'", data.connection);
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool tuchoisp(string msp)
        {
            data.connect();
            SqlCommand command = new SqlCommand("delete from yeucau where maSp='" + msp + "'", data.connection);
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public DataTable Kiemtratontai(string msp, DateTime nsx)
        {
            data.connect();
            SqlCommand sql = new SqlCommand("select * from sanpham where maSp=@msp and nsx=@nsx",data.connection);
            sql.Parameters.Add("@msp", SqlDbType.NVarChar).Value = msp;
            sql.Parameters.Add("@nsx", SqlDbType.Date).Value = nsx;
            DataTable dtb = new DataTable();
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            dta.Fill(dtb);
            return dtb;
        }
        public bool giamslkhichapnhan(string msp,DateTime nsx,int sl)
        {
            data.connect();
            SqlCommand sql = new SqlCommand("update sanpham set soluong=soluong-@sl where maSp=@msp and nsx=@nsx", data.connection);
            sql.Parameters.Add("@msp", SqlDbType.NVarChar).Value = msp;
            sql.Parameters.Add("@sl", SqlDbType.Int).Value = sl;
            sql.Parameters.Add("@nsx", SqlDbType.DateTime).Value = nsx;
            if (sql.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
    }
}
