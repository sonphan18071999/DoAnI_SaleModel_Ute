﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data.OleDb;

namespace WindowsFormsApp1.classCongviec
{
    class DT
    {
        DataProvider data = new DataProvider();
        public bool themdt(string name,string sdt,string add,int nam)
        {
            data.connect();
            SqlCommand command = new SqlCommand("insert into doitac (tenCty,addr,sdt,sonamhoptac) values (@name,@add,@sdt,@nam)", data.connection);
            command.Parameters.Add("@name",SqlDbType.NVarChar).Value = name;
            command.Parameters.Add("@add", SqlDbType.NVarChar).Value = add;
            command.Parameters.Add("@sdt", SqlDbType.NVarChar).Value = sdt;
            command.Parameters.Add("@nam", SqlDbType.Int).Value = nam;
            if (command.ExecuteNonQuery()==1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool xoadt(string name)
        {
            data.connect();
            SqlCommand command = new SqlCommand("delete from doitac where tenCty=N'"+name+"'", data.connection);
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
        public bool suadt(int id,string name, string sdt, string add, int nam)
        {
            data.connect();
            SqlCommand command = new SqlCommand("update doitac set tenCty=@name,addr=@addr,sdt=@sdt,sonamhoptac=@nam where id="+id, data.connection);
            command.Parameters.Add("@name", SqlDbType.NVarChar).Value = name;
            command.Parameters.Add("@addr", SqlDbType.NVarChar).Value = add;
            command.Parameters.Add("@sdt", SqlDbType.NVarChar).Value = sdt;
            command.Parameters.Add("@nam", SqlDbType.Int).Value = nam;
            if (command.ExecuteNonQuery() == 1)
            {
                data.disconnect();
                return true;
            }
            return false;
        }
    }
}
