﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data.OleDb;

namespace WindowsFormsApp1.usercontrol
{
    public partial class chinhanh : UserControl
    {
        public chinhanh()
        {
            InitializeComponent();
        }
        DataProvider dtp = new DataProvider();
        classCongviec.NV nv = new classCongviec.NV();
        classCongviec.CN cn = new classCongviec.CN();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dtp.connect();
                int mcn = int.Parse(txtmaCN.Text);
                string dc = txtDC.Text;
                string nql = txttmb.Text;
                float tmb = float.Parse(txttmb.Text);
                if (cn.themchinhanh(mcn, dc,tmb) == true)
                {
                    DialogResult dlr = MessageBox.Show("Thêm chi nhánh mới thành công", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    load();
                }
               
                else
                {
                    DialogResult dlr = MessageBox.Show("Quản lí không thuộc công ty", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception)
            {
                DialogResult dlr = MessageBox.Show("Có lỗi", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        public void load()
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("select * from chinhanh", dtp.connection);
            DataTable a = new DataTable();
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            dta.Fill(a);
            cbchinhanh.DataSource = a;
            cbchinhanh.DisplayMember = "STT";
            cbchinhanh.ValueMember = "STT";
            SqlCommand sql1 = new SqlCommand("select * from chinhanh", dtp.connection);
            DataTable b = new DataTable();
            dta = new SqlDataAdapter(sql1);
            dta.Fill(b);
            dataGridView1.DataSource = b;
            SqlCommand sql2 = new SqlCommand("select * from quanli", dtp.connection);
            DataTable c = new DataTable();
            dta = new SqlDataAdapter(sql2);
            dta.Fill(c);
            dataGridView2.DataSource = c;
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void chinhanh_Load(object sender, EventArgs e)
        {
            load();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
             
                dtp.connect();
                SqlCommand sql = new SqlCommand("select [User] from quanli where chinhanh=" + cbchinhanh.Text , dtp.connection);
                if (sql.ExecuteScalar() != null)
                {
                    DialogResult dlr = MessageBox.Show("Chi nhánh này đã có QL,bạn muốn tiếp tục ko", "Đối tác", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    {
                        if (dlr == DialogResult.OK)
                        {
                            
                            if (nv.giangcap(sql.ExecuteScalar().ToString(),int.Parse(cbchinhanh.SelectedValue.ToString())))
                            {
                                DialogResult dlr1 = MessageBox.Show("Đã thay đổi", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                string user = txtuser.Text;
                string name = txtten.Text;
                string pass = txtpassword.Text;
                string dc = txtdiachi.Text;
                DateTime ns = DateTime.ParseExact(txtNS.Text, "dd/MM/yyyy", null);
                string sdt = txtsdt.Text;
                float luong = float.Parse(txtluong.Text);
                int chinhanh = int.Parse(cbchinhanh.SelectedValue.ToString());
                SqlCommand sql1 = new SqlCommand("select [User] from quanli where [User]='"+txtuser.Text+"'", dtp.connection);
            SqlDataAdapter dta = new SqlDataAdapter(sql1);
            DataTable a = new DataTable();
            dta.Fill(a);
            if (a.Rows.Count == 0)
            {
                if (nv.themQL(user, name, pass, dc, ns, sdt, luong, chinhanh))
                {
                    DialogResult dlr2 = MessageBox.Show("Thêm Quản lí thành công", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    load();
                }
                else
                {
                    DialogResult dlr1 = MessageBox.Show("lỗi", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            else
            {
                DialogResult dlr1 = MessageBox.Show("Mã này đã tồn tại" +
                    "", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

     
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dtp.connect();
            if(cn.xoachinhanh(int.Parse(txtmaCN.Text))==true)
            {
                DialogResult dlr = MessageBox.Show("Xóa thành công", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                load();
            }
            else
            {
                DialogResult dlr = MessageBox.Show("lỗi", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView2_Click(object sender, EventArgs e)
        {
            txtuser.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtpassword.Text= dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtdiachi.Text= dataGridView2.CurrentRow.Cells[2].Value.ToString();
            DateTime date = Convert.ToDateTime(dataGridView2.CurrentRow.Cells[3].Value);
            var shortDate = date.ToString("dd-MM-yyyy");
            txtNS.Text = shortDate;
            txtsdt.Text= dataGridView2.CurrentRow.Cells[4].Value.ToString();
            txtluong.Text= dataGridView2.CurrentRow.Cells[5].Value.ToString();
            cbchinhanh.Text= dataGridView2.CurrentRow.Cells[6].Value.ToString();
            txtten.Text= dataGridView2.CurrentRow.Cells[7].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string user = txtuser.Text;
            string name = txtten.Text;
            string pass = txtpassword.Text;
            string dc = txtdiachi.Text;
            DateTime ns = DateTime.ParseExact(txtNS.Text, "dd/MM/yyyy", null);
            string sdt = txtsdt.Text;
            float luong = float.Parse(txtluong.Text);
            int chinhanh = int.Parse(cbchinhanh.SelectedValue.ToString());
            if (nv.SuaQL(user,name,pass,dc,ns,sdt,luong,chinhanh)==true)
            {
                DialogResult dlr = MessageBox.Show("Thay đổi thành công", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                load();
            }
            else
            {
                DialogResult dlr = MessageBox.Show("lỗi", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
