﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;

namespace WindowsFormsApp1.usercontrol
{
    public partial class khachhang : UserControl
    {
        public khachhang()
        {
            InitializeComponent();
        }
        DataProvider dtp = new DataProvider();
        private void khachhang_Load(object sender, EventArgs e)
        {
            load();
            btnxoa.Enabled = false;
        }
        private void load()
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("select * from khachhang", dtp.connection);
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            DataTable data = new DataTable();
            dta.Fill(data);
            dataGridView1.DataSource = data;
        }
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            txtName.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtsdt.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtgmail.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtdtl.Text= dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnxoa.Enabled = true ;
            dtp.connect();
            SqlCommand sql = new SqlCommand("select * from khachhang where Convert(int,datepart(yyyy,getdate()))-Convert(int,datepart(yyyy,ngaygiaodichgannhat))>2", dtp.connection);
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            DataTable data = new DataTable();
            dta.Fill(data);
            dataGridView1.DataSource = data;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            load();
            btnxoa.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            classCongviec.KH kh = new classCongviec.KH();
        
            if (kh.xoaKhachhang(txtsdt.Text.ToString()) == true)
            {
                MessageBox.Show("Xóa khách hàng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtdtl.Text = "";
                txtgmail.Text = "";
                txtName.Text = "";
                txtsdt.Text = "";
            }
            else
            {
                MessageBox.Show("Không xóa đc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
