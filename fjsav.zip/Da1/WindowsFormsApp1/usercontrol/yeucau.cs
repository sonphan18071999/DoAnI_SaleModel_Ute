﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.usercontrol
{
    public partial class yeucau : UserControl
    {
        public yeucau()
        {
            InitializeComponent();
        }
        DataProvider con = new DataProvider();
        SqlDataAdapter dta = new SqlDataAdapter();
        string ad;
        private void loadDta()
        {
            con.connect();
            DataTable dtb = new DataTable();
            dta = new SqlDataAdapter("select MaSP,TenSP,DonGia,DonViTinh,SoLuong,chinhanh,nsx,hsd from yeucau where trangthai=0", con.connection);
            dta.Fill(dtb);
            dataGridView1.DataSource = dtb;
            con.disconnect();
            radioall.Checked = true;
            
        }

        private void A_Tick(object sender, EventArgs e)
        {
            loadDta();
            radioChinhanh1.Checked = false;
            radiochinhanh2.Checked = false;
            radioall.Checked = true;
        }

        private void yeucau_Load(object sender, EventArgs e)
        {
            try
            {
                loadDta();
                Timer a = new Timer();
                a.Interval = 1000;
                a.Tick += A_Tick;
                a.Start();
            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void A_Tick1(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void radioall_Click(object sender, EventArgs e)
        {
            radioChinhanh1.Checked = false;
            radiochinhanh2.Checked = false;
            loadDta();
        }

        private void radiochinhanh2_Click(object sender, EventArgs e)
        {
            radioChinhanh1.Checked = false;
            radioall.Checked = false;
            con.connect();
            DataTable dtb = new DataTable();
            dta = new SqlDataAdapter("select MaSP,TenSP,DonGia,DonViTinh,SoLuong,chinhanh,nsx,hsd from yeucau where trangthai=0 and chinhanh=2", con.connection);
            dta.Fill(dtb);
            dataGridView1.DataSource = dtb;
            con.disconnect();
        }

        private void radioChinhanh1_Click(object sender, EventArgs e)
        {
            radiochinhanh2.Checked = false;
            radioall.Checked = false;
            con.connect();
            DataTable dtb = new DataTable();
            dta = new SqlDataAdapter("select MaSP,TenSP,DonGia,DonViTinh,SoLuong,chinhanh,nsx,hsd from yeucau where trangthai=0 and chinhanh=1", con.connection);
            dta.Fill(dtb);
            dataGridView1.DataSource = dtb;
            con.disconnect();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            txttenSP.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtSL.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtgia.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox2.Text= dataGridView1.CurrentRow.Cells[4].Value.ToString();
            ad = dataGridView1.CurrentRow.Cells[0].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string ms = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                DateTime dt = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[6].Value.ToString());
                classCongviec.SP sp = new classCongviec.SP();
                if(sp.chapnhansp(ad)==true)
                {
                    con.connect();
                    SqlCommand sql = new SqlCommand("select soluong from sanpham where maSp=@msp and nsx=@nsx", con.connection);
                    sql.Parameters.Add("@msp", SqlDbType.NVarChar).Value = ms; 
                    sql.Parameters.Add("@nsx", SqlDbType.Date).Value =dt;
                    if (int.Parse(sql.ExecuteScalar().ToString())>int.Parse(txtSL.Text))
                    {
                        DialogResult dlr = MessageBox.Show("Sản phẩm được chấp nhận", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (dlr == DialogResult.OK)
                        {
                            if (sp.giamslkhichapnhan(ms, dt, int.Parse(txtSL.Text))==true)
                            {
                                loadDta();
                                radioChinhanh1.Checked = false;
                                radiochinhanh2.Checked = false;
                                radioall.Checked = true;
                                txttenSP.Text = "";
                                txtSL.Text = "";
                                txtgia.Text = "";
                                textBox1.Text = "";
                                textBox2.Text = "";
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("Không đủ số lượng", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                classCongviec.SP sp = new classCongviec.SP();
                if (sp.tuchoisp(ad) == true)
                {
                    DialogResult dlr = MessageBox.Show("Sản phẩm đã bị từ chối", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr == DialogResult.OK)
                    {
                        loadDta();
                        radioChinhanh1.Checked = false;
                        radiochinhanh2.Checked = false;
                        radioall.Checked = true;
                        txttenSP.Text = "";
                        txtSL.Text = "";
                        txtgia.Text = "";
                        textBox1.Text = "";
                        textBox2.Text = "";
                    }
                }

            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
