﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.Text.RegularExpressions;

namespace WindowsFormsApp1.usercontrol
{
    public partial class radioall : UserControl
    {
        public radioall()
        {
            InitializeComponent();
        }
        classCongviec.SP sp = new classCongviec.SP();
        DataProvider data = new DataProvider();
        SqlDataAdapter dtadapter = new SqlDataAdapter();
        private void reset()
        {
            loadData();
            txtCty.Text = "";
            txtDonvi.Text = "";
            txtGiaban.Text = "";
            txtMasp.Text = "";
            txtTenSp.Text = "";
            txtNSX.Text = "";
            txtHSD.Text = "";
            txtPercent.Text = "";
        }
        private void loadData()
        {
            data.connect();
            SqlCommand cmd = new SqlCommand("select * from sanpham", data.connection);
            DataTable dbtable = new DataTable();
            dtadapter = new SqlDataAdapter(cmd);
            dtadapter.Fill(dbtable);
            dataGridView1.DataSource = dbtable;
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            reset();
        }
        public void LoadComboBox()
        {
            DataTable dt = new DataTable();
            data.connect();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * From doitac",data.connection);
                da.Fill(dt);
                data.disconnect();
            }
            catch (Exception ex)
            {
                throw new Exception("Error " + ex.ToString());
            }
            try
            {
                txtCty.DataSource = dt;
                txtCty.DisplayMember = "tenCty";
                txtCty.ValueMember = "ID";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void sanpham_Load(object sender, EventArgs e)
        {
            reset();
            LoadComboBox();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string msp = txtMasp.Text;
                string tensp = txtTenSp.Text;
                int cty = Convert.ToInt32(txtCty.SelectedValue.ToString());
                float giaban = float.Parse(txtGiaban.Text);
                string dv = Convert.ToString(txtDonvi.Text);
                DateTime a = DateTime.ParseExact(txtNSX.Text, "dd/MM/yyyy", null);
                DateTime b = DateTime.ParseExact(txtHSD.Text, "dd/MM/yyyy", null);
                if (a > b)
                {
                    MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    float per = float.Parse(txtPercent.Text);
                    int sl = Convert.ToInt32(txtsl.Text);
                    if (sp.Kiemtratontai(msp, a).Rows.Count == 0)
                    {
                        if (sp.themsp(msp, tensp, cty, giaban, dv, a, b, per, sl) == true)
                        {
                            DialogResult dlr = MessageBox.Show("Sản phẩm mới được thêm", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (dlr == DialogResult.OK)
                            {
                                reset();
                            }
                        }
                    }
                    else
                    {
                        if (sp.themslkhitontai(msp, a, sl) == true)
                        {
                            DialogResult dlr = MessageBox.Show("Sản phẩm được thay đổi", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (dlr == DialogResult.OK)
                            {
                                reset();
                            }
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string masp = txtMasp.Text;
                DateTime date= DateTime.ParseExact(txtNSX.Text, "dd/MM/yyyy", null);
                if (sp.xoasp(masp,date) == true)
                {
                    DialogResult dlr = MessageBox.Show("Sản phẩm đã xóa", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr == DialogResult.OK)
                    {
                        reset();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            txtMasp.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtTenSp.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtGiaban.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtDonvi.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtsl.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            DateTime date = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[6].Value);
            var shortDate = date.ToString("dd-MM-yyyy");
            txtNSX.Text = shortDate;
            DateTime date1 = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[7].Value);
            var shortDate1 = date1.ToString("dd-MM-yyyy");
            txtHSD.Text= shortDate1;
            txtPercent.Text= dataGridView1.CurrentRow.Cells[8].Value.ToString();
            string k;
            DataTable dt = new DataTable();
            data.connect();
            try
            {
                SqlCommand sql = new SqlCommand("Select tenCty From doitac where id=" + dataGridView1.CurrentRow.Cells[2].Value.ToString(), data.connection);
                k = sql.ExecuteScalar().ToString();
                SqlDataAdapter da = new SqlDataAdapter("Select * From doitac", data.connection);
                da.Fill(dt);
                data.disconnect();
            }
            catch (Exception ex)
            {
                throw new Exception("Error " + ex.ToString());
            }
            try
            {
                txtCty.DataSource = dt;
                txtCty.DisplayMember = "tenCty";
                txtCty.ValueMember = "ID";
                txtCty.Text = k;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi khi load dữ liệu!\n", ex.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string msp = txtMasp.Text;
            string tensp = txtTenSp.Text;
            int cty = Convert.ToInt32(txtCty.SelectedValue.ToString());
            float giaban = float.Parse(txtGiaban.Text);
            string dv = Convert.ToString(txtDonvi.Text);
            DateTime a = DateTime.ParseExact(txtNSX.Text, "dd/MM/yyyy", null);
            DateTime b = DateTime.ParseExact(txtHSD.Text, "dd/MM/yyyy", null);
            float per = float.Parse(txtPercent.Text);
            int sl = Convert.ToInt32(txtsl.Text);
            if (sp.suasp(msp, tensp, cty, giaban, dv,a,b,per,sl) == true)
            {
                DialogResult dlr = MessageBox.Show("Cập nhật thành công", "Sản phẩm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (dlr == DialogResult.OK)
                {
                    reset();
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            data.connect();
            SqlCommand cmd = new SqlCommand("select * from sanpham where tenSP like '%" + textBox1.Text + "%'", data.connection);
            DataTable dbtable = new DataTable();
            dtadapter = new SqlDataAdapter(cmd);
            dtadapter.Fill(dbtable);
            dataGridView1.DataSource = dbtable;
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
           
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            
        }
    }
}
