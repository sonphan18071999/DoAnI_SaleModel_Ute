﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;

namespace WindowsFormsApp1.usercontrol
{
    public partial class doitac : UserControl
    {
        public doitac()
        {
            InitializeComponent();
        }
        classCongviec.DT dt=new classCongviec.DT();
        DataProvider data = new DataProvider();
        SqlDataAdapter dtadapter = new SqlDataAdapter();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txtName.Text;
                string add = txtadd.Text;
                string sdt = txtsdt.Text;
                string year = txtyear.Text;
                int yearint = Convert.ToInt32(year);
                if (dt.themdt(name,sdt,add, yearint) == true)
                {
                    DialogResult dlr= MessageBox.Show("Đối tác mới được thêm", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr==DialogResult.OK)
                    {
                        reset();
                    }
                }
            }
            catch 
            {
                MessageBox.Show("Có lỗi xảy ra", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void reset()
        {
            loadData();
            txtName.Text="";
            txtadd.Text = "";
            txtsdt.Text = "";
            txtyear.Text = "";
        }

        private void loadData()
        {
            data.connect();
            SqlCommand cmd = new SqlCommand("select * from doitac", data.connection);
            DataTable dbtable = new DataTable();
            dtadapter = new SqlDataAdapter(cmd);
            dtadapter.Fill(dbtable);
            dataGridView1.DataSource = dbtable;
            dataGridView1.Columns[0].Width = 20;
            dataGridView1.Columns[1].Width = 150;
            dataGridView1.Columns[3].Width = 20;
        }

        private void doitac_Load(object sender, EventArgs e)
        {
            loadData();
        }
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            txtName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtsdt.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtadd.Text= dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtyear.Text= dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txtName.Text;

                if (dt.xoadt(name) == true)
                {
                    DialogResult dlr = MessageBox.Show("Đối tác đã xóa", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr == DialogResult.OK)
                    {
                        reset();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                string name = txtName.Text;
                string add = txtadd.Text;
                string sdt = txtsdt.Text;
                string year = txtyear.Text;
                int yearint = Convert.ToInt32(year);
                if (dt.suadt(id,name,sdt,add,yearint)==true)
                { 
                    DialogResult dlr = MessageBox.Show("Cật nhập thành công", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dlr == DialogResult.OK)
                    {
                        reset();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Có lỗi xảy ra", "Đối tác", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            data.connect();
            SqlCommand cmd = new SqlCommand("select * from doitac where tenCty like '%"+textBox5.Text+"%'", data.connection);
            DataTable dbtable = new DataTable();
            dtadapter = new SqlDataAdapter(cmd);
            dtadapter.Fill(dbtable);
            dataGridView1.DataSource = dbtable;
            dataGridView1.Columns[0].Width = 20;
            dataGridView1.Columns[1].Width = 150;
            dataGridView1.Columns[3].Width = 20;
        }
    }
}
