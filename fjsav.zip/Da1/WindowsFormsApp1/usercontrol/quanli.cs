﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;
namespace WindowsFormsApp1.usercontrol
{
    public partial class quanli : UserControl
    {
        public quanli()
        {
            InitializeComponent();
        }
        DataProvider dtp = new DataProvider();
        private void load(string a)
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("select * from thuchi where chinhanh="+a, dtp.connection);
            DataTable dtb = new DataTable();
            SqlDataAdapter sqldta = new SqlDataAdapter(sql);
            sqldta.Fill(dtb);
            dataGridView1.DataSource = dtb;
            //lấy ngày cần xem
            SqlCommand sql1 = new SqlCommand("select chinhanh from thuchi", dtp.connection);
            DataTable dtb1 = new DataTable();
            SqlDataAdapter sqldta1 = new SqlDataAdapter(sql1);
            SqlCommand sql7 = new SqlCommand("select * from chinhanh", dtp.connection);
            DataTable k = new DataTable();
            SqlDataAdapter dta = new SqlDataAdapter(sql7);
            dta.Fill(k);
            cbdate.DataSource = k;
          
           
            cbdate.DisplayMember = "Diachi";
            cbdate.ValueMember = "STT";
            dtp.connect();
            SqlCommand sql2 = new SqlCommand("select sum(thu) from thuchi where chinhanh=" + a , dtp.connection);
            txtTT.Text = sql2.ExecuteScalar().ToString();
            SqlCommand sql3 = new SqlCommand("select sum(chi) from thuchi where chinhanh=" + a , dtp.connection);
            txtChi.Text = sql3.ExecuteScalar().ToString();
            SqlCommand sql4 = new SqlCommand("select luong*giolam-tre*1000 from nhanvien where chinhanh=" + a , dtp.connection);
            txtLuongNV.Text = sql4.ExecuteScalar().ToString();
            txtLoinhuan.Text = Convert.ToString(float.Parse(txtTT.Text) - float.Parse(txtChi.Text) - float.Parse(txtLuongNV.Text));
        }
        private void quanli_Load(object sender, EventArgs e)
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("select * from chinhanh", dtp.connection);
            DataTable a = new DataTable();
            SqlDataAdapter dta = new SqlDataAdapter(sql);
            dta.Fill(a);
            cbdate.DataSource = a;
            
            cbdate.DisplayMember = "Diachi";
            cbdate.ValueMember = "STT";
            load(cbdate.SelectedValue.ToString());
        }

        private void cbdate_ValueMemberChanged(object sender, EventArgs e)
        {
            dtp.connect();
            SqlCommand sql = new SqlCommand("select top(5)ngaycatnhap,chinhanh,thu,chi from thuchi where chinhanh="+cbdate.SelectedValue, dtp.connection);
            DataTable dtb = new DataTable();
            SqlDataAdapter sqldta = new SqlDataAdapter(sql);
            sqldta.Fill(dtb);
            foreach (var series in thu.Series)
            {
                series.Points.Clear();
            }
            for (int i=0;i<dtb.Rows.Count;i++)
            {
                thu.Series["thu"].Points.AddXY(dtb.Rows[i][0].ToString(), float.Parse(dtb.Rows[i][2].ToString()));
                thu.Series["chi"].Points.AddXY(dtb.Rows[i][0].ToString(), float.Parse(dtb.Rows[i][3].ToString()));
            }


        }
    }
}
