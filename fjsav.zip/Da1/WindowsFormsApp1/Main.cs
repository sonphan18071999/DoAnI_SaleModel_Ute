﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        usercontrol.doitac a = new usercontrol.doitac();
        usercontrol.radioall b = new usercontrol.radioall();
        usercontrol.yeucau c = new usercontrol.yeucau();
        usercontrol.khachhang d = new usercontrol.khachhang();
        usercontrol.quanli k = new usercontrol.quanli();
        usercontrol.chinhanh r = new usercontrol.chinhanh();
        private void button1_Click(object sender, EventArgs e)
        {
            a.Visible = true;
            b.Visible = false;
            c.Visible = false;
            d.Visible = false;
            k.Visible = false;
            r.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Controls.Add(a);
            panel1.Controls.Add(b);
            panel1.Controls.Add(c);
            panel1.Controls.Add(d);
            panel1.Controls.Add(k);
            panel1.Controls.Add(r);
        }

        private void panel1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            a.Visible = false;
            c.Visible = false;
            b.Visible = true;
            d.Visible = false;
            k.Visible = false;
            r.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            a.Visible = false;
            c.Visible = true;
            b.Visible = false;
            d.Visible = false;
            k.Visible = false;
            r.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            a.Visible = false;
            c.Visible = false;
            b.Visible = false;
            d.Visible = true;
            k.Visible = false;
            r.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            a.Visible = false;
            c.Visible = false;
            b.Visible = false;
            d.Visible = false;
            k.Visible = true;
            r.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            a.Visible = false;
            c.Visible = false;
            b.Visible = false;
            d.Visible = false;
            k.Visible = false;
            r.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            lienlac ll = new lienlac();
            ll.Show();
        }
    }
}
