﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;

namespace WindowsFormsApp17
{
    public partial class EditE : UserControl
    {
        public EditE()
        {
            InitializeComponent();
        }
        DataProvider data = new DataProvider();
        MANAGE st = new MANAGE();
        SqlCommand cmd;
        bool verif()
        {
            if ((textID.Text.Trim() == "") || (textFname.Text.Trim() == "" || textLname.Text.Trim() == "" || TextPhone.Text.Trim() == "" || pictureBox1.Image == null || textAddress.Text.Trim() == null))
            {
                return false;
            }
            else return true;
        }
        private void EditE_Load(object sender, EventArgs e)
        {
            data.connect();
            // TODO: This line of code loads data into the 'qLNHDataSet.infoEm' table. You can move, or remove it, as needed.
            cmd = new SqlCommand("select * from infoEm as info,lgNV as lg where info.id=lg.id");
            fillGrid(cmd);
            int a = dataGridView1.Rows.Count - 1;
            TotalLb.Text = "Total:" + a;
        }
        void fillGrid(SqlCommand a)
        {
            this.infoEmTableAdapter.Fill(this.qLNHDataSet.infoEm);
            dataGridView1.ReadOnly = true;
            DataGridViewImageColumn pic = new DataGridViewImageColumn();
            dataGridView1.RowTemplate.Height = 50;
            dataGridView1.DataSource = st.getStudent(a);
            pic = (DataGridViewImageColumn)dataGridView1.Columns[8];
            pic.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dataGridView1.AllowUserToAddRows = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textID.Text = "";
            textFname.Text = "";
            textLname.Text = "";
            TextBDate.Value = DateTime.Now;
            TextPhone.Text = "";
            textAddress.Text = "";
            textPosition.Text = "";
            TextWs.Text = "";
            pictureBox1.Image = null;
            Malebutton.Checked = true;
            this.infoEmTableAdapter.Fill(this.qLNHDataSet.infoEm);
            SqlCommand cmd = new SqlCommand("Select * from infoEm");
            fillGrid(cmd);
            int a = dataGridView1.Rows.Count - 1;
            TotalLb.Text = "Total:" + a;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int studentId = Convert.ToInt32(textID.Text);
            string vtEm = textPosition.Text;
            if ((MessageBox.Show("Are You Sure You Want To Delete This Staff", "Delete Staff", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                if (st.deleteemployee(studentId, vtEm))
                {
                    DialogResult dlr = MessageBox.Show("Staff Deleted", "Delete Staff", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (dlr == DialogResult.Yes)
                    {
                        this.Refresh();
                        textID.Text = "";
                        textFname.Text = "";
                        textLname.Text = "";
                        TextBDate.Value = DateTime.Now;
                        TextPhone.Text = "";
                        textAddress.Text = "";
                        textPosition.Text = "";
                        TextWs.Text = "";
                        Malebutton.Checked = true;
                        this.infoEmTableAdapter.Fill(this.qLNHDataSet.infoEm);
                        SqlCommand cmd = new SqlCommand("Select * from infoEm");
                        fillGrid(cmd);
                        int a = dataGridView1.Rows.Count - 1;
                        TotalLb.Text = "Total:" + a;
                    }
                }
                else
                {
                    MessageBox.Show("Employee Not Deleted", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textID.Text);
            string fname = textFname.Text;
            string lname = textLname.Text;
            DateTime bdate = TextBDate.Value;
            string phone = TextPhone.Text;
            string adrs = textAddress.Text;
            string position = textPosition.Text;
            int ws = Convert.ToInt32(TextWs.Text);
            string gender = "Male";
            if (femaleButton.Checked)
            {
                gender = "Female";
            }
            MemoryStream pic = new MemoryStream();
            int born_year = TextBDate.Value.Year;
            int this_year = DateTime.Now.Year;
            if ((this_year - born_year) < 10 || (this_year - born_year) > 100)
            {
                MessageBox.Show("The Student Age is wrong", "Invalid Birth!");
            }
            else if (verif())
            {
                pictureBox1.Image.Save(pic, pictureBox1.Image.RawFormat);
                if (st.updateEmployee(id, fname, lname, bdate, gender, phone, position, adrs, pic, ws))
                {
                    MessageBox.Show("Added", "Edit Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Refresh();
                }
                else
                {
                    MessageBox.Show("Error", "Edit Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            if (verif() == false) MessageBox.Show("Empty", "Edit Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SaveFileDialog tvf1 = new SaveFileDialog();
            tvf1.FileName = ("student_" + textID.Text);
            if (tvf1.ShowDialog() == DialogResult.OK)
            {
                GhiDuLieuVaoText(dataGridView1, tvf1.FileName + (".txt"));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string find = textFind.Text;
            if (Fid.Checked)
            {
                cmd = new SqlCommand("select * from infoEm where id=" + Convert.ToInt32(find));
            }
            if (FfName.Checked)
            {
                cmd = new SqlCommand("select * from infoEm where concat(fname) like '" + find + "'");
            }
            fillGrid(cmd);
        }
        public void GhiDuLieuVaoText(DataGridView data, string teptext)
        {
            // chi vao tep text
            StreamWriter fr = File.AppendText(teptext);
            // duyet tung hang trong ta ta
            for (int i = 0; i < data.Rows.Count - 1; i++)
            {
                string dong = "";// gan gia tri cua dong la gia tri trang tuong tuong voi do o
                                 // duyet tung cot trong data
                for (int j = 0; j < data.Columns.Count - 1; j++)
                {
                    dong = dong + data[j, i].Value.ToString() + "#";
                }
                // loai bo dau phay cuoi cung trong chuoi 
                dong = dong + data[data.Columns.Count - 1, i].Value.ToString();
                fr.WriteLine(dong);
            }
            fr.Close();

        }

        private void Malebutton_CheckedChanged(object sender, EventArgs e)
        {
            femaleButton.Checked = false;
        }

        private void femaleButton_CheckedChanged(object sender, EventArgs e)
        {
            Malebutton.Checked = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if ((opf.ShowDialog() == DialogResult.OK))
            {
                pictureBox1.Image = Image.FromFile(opf.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog tvf = new SaveFileDialog();
            tvf.FileName = ("student_" + textID.Text);
            if ((pictureBox1.Image == null))
            {
                MessageBox.Show("No Image");
            }
            else if ((tvf.ShowDialog() == DialogResult.OK))
            {
                pictureBox1.Image.Save(tvf.FileName + ("." + ImageFormat.Jpeg.ToString()));
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            textID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textFname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textLname.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            TextBDate.Value = (DateTime)dataGridView1.CurrentRow.Cells[3].Value;
            if ((dataGridView1.CurrentRow.Cells[4].Value.ToString() == "Female"))
            {
                femaleButton.Checked = true;
            }
            else Malebutton.Checked = true;
            TextPhone.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textPosition.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            textAddress.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            TextWs.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            byte[] pic;
            pic = (byte[])dataGridView1.CurrentRow.Cells[8].Value;
            MemoryStream picture = new MemoryStream(pic);
            pictureBox1.Image = Image.FromStream(picture);
        }
    }
}
